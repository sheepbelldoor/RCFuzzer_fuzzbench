test-001.mp4: simple audio+video file
test-002.mp4: same as test-001.mp4 but fragmented
